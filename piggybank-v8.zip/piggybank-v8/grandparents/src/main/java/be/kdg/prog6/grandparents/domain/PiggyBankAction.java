package be.kdg.prog6.grandparents.domain;

public enum PiggyBankAction {

    PUT_IN,
    TAKE_OUT;
}
