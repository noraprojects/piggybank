package be.kdg.prog6.grandparents.events;

public interface Event {
}
