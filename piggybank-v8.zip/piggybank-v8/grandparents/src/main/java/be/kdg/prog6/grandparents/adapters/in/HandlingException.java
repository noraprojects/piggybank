package be.kdg.prog6.grandparents.adapters.in;

public class HandlingException extends RuntimeException {
    public HandlingException(Exception e) {
        super(e);
    }
}
