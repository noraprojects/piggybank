package be.kdg.prog6.common.events;

public enum EventCatalog {

    FAMILY_RECEIVED_PIGGYBANK,
    PIGGYBANK_ACTIVITY_CREATED, //this should better be split up in 2 events
    AGENDA_ACTIVITY_CREATED; // same


}
