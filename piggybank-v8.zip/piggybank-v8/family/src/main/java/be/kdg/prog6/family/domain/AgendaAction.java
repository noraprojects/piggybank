package be.kdg.prog6.family.domain;

public enum AgendaAction {

    BOOK,
    CANCEL;
}
