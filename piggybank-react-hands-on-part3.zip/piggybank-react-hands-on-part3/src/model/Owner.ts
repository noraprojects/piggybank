export type Owner = {
    id: string
    name: string
    profilePic: string
}
