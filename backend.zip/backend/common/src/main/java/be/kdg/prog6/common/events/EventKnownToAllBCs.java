package be.kdg.prog6.common.events;

public record EventKnownToAllBCs() {
}
