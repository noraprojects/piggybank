package be.kdg.prog6.landside.adapters.in;

public class AppointmentAmqpAdapter {
}
