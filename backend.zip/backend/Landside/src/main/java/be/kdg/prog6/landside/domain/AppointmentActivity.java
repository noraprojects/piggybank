package be.kdg.prog6.landside.domain;

public class AppointmentActivity {
}
