package be.kdg.prog6.landside.domain;

public enum AppointmentAction {
    APPROVED, CANCELED, COMPLETED
}
