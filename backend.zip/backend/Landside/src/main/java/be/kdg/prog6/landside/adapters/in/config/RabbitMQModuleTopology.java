package be.kdg.prog6.landside.adapters.in.config;

public class RabbitMQModuleTopology {
}
